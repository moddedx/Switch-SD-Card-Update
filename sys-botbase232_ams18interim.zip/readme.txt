This is an interim version of sys-botbase for HOS 19.0.0/AMS 18.x. You may run into crashes and errors that cannot be fixed until a stable version of libnx/atmosphere has been released.

Please update to the latest stable release of sys-botbase as soon as it is available. Do not use this long-term.

No support is provided for this bleeding edge version of sys-botbase. Please wait for a stable release if you run into issues.

-berichan